//
//  DetailViewController.swift
//  TestProject
//
//  Created by USER on 11/04/20.
//  Copyright © 2020 Sai Kishore. All rights reserved.
//

import UIKit
import WebKit

class DetailViewController: TestProjectBaseVC {
    
    @IBOutlet weak var detailWebView: WKWebView!
    var detailNewsStr: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        detailWebView.load(NSURLRequest(url: NSURL(string: detailNewsStr ?? "")! as URL) as URLRequest)
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
          self.navigationController?.navigationBar.makeDefault("Detail News")
          self.navigationItem.leftBarButtonItem = UIBarButtonItem.menuOrBackButton(self, action: #selector(backAction), imageName: "Back-white")
      }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
