//
//  HomeViewController.swift
//  TestProject
//
//  Created by SAI on 10/04/20.
//  Copyright © 2020 Sai Kishore. All rights reserved.
//

import UIKit
import SDWebImage

class HomeViewController: TestProjectBaseVC {
    
    lazy var homeNewsArr = [Docs]()
    var fromIndex = 0
    var pageCount: Int = 0
    let totalItems = 100

    fileprivate var activityIndicator: LoadMoreActivityIndicator!
    
    @IBOutlet weak var newsCollectionView: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
//        startAnimatingActivityIndicator()
        newsCollectionView.register(UINib(nibName: "NewsCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "NewsCollectionViewCell")
        homeNews(pageCount: 0)
        activityIndicator = LoadMoreActivityIndicator(scrollView: newsCollectionView, spacingFromLastCell: 10, spacingFromLastCellWhenLoadMoreActionStart: 60)

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.makeDefault("News Gallery")
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.menuOrBackButton(self, action: #selector(backAction), imageName: "Back-white")
    }
    
    
    func homeNews(pageCount: Int){
    RequestManager.shared.fetchHomeNews(pageCount: pageCount, completedSuccessfully: {[weak self] (fetchHomeDetails)  in
             DispatchQueue.main.async {
                var items = self?.homeNewsArr
                items?.append(contentsOf: fetchHomeDetails.response?.docs ?? [])
                 if (self?.fromIndex ?? 0) < (items?.count ?? 0) {
                     self?.homeNewsArr = items ?? []
                     self?.fromIndex = items?.count ?? 0
                     DispatchQueue.main.async {
                         self?.newsCollectionView.delegate = self
                         self?.newsCollectionView.dataSource = self
                         self?.newsCollectionView.reloadData()
                     }
                 
                 }
             }
         }) { (error) in
             self.showAlert(withTitle: "Error", message: error.message, okHandler: { () -> Void? in
                 return nil
             })
             self.stopAnimatingActivityIndicator()
         }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension HomeViewController : UICollectionViewDelegate, UICollectionViewDataSource {
   
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return homeNewsArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let homeNewsCell = collectionView.dequeueReusableCell(withReuseIdentifier: "NewsCollectionViewCell", for: indexPath) as! NewsCollectionViewCell
        
        homeNewsCell.titleLbl.text = homeNewsArr[indexPath.row].section_name ?? ""
        homeNewsCell.snippetLbl.text = homeNewsArr[indexPath.row].snippet ?? ""
        // FIx me: -  with passing the image url name
        /* Uncomment and pass image url string name to show the images in collection view cell
        homeNewsCell.imageView.sd_setImage(with: URL(string: homeNewsArr[indexPath.row].document_type ?? ""), placeholderImage: UIImage(named: "photo"))
        */
        homeNewsCell.dateLbl.text = String(homeNewsArr[indexPath.row].pub_date?.dropLast(14) ?? "")
        return homeNewsCell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let detailNewVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        detailNewVC.detailNewsStr =  homeNewsArr[indexPath.row].web_url 
        self.navigationController?.pushViewController(detailNewVC, animated: false)
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
       let currentOffset = scrollView.contentOffset.y
       let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height

       if maximumOffset - currentOffset <= 100.0 {
            pageCount += 1
            homeNews(pageCount: pageCount)
       }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        activityIndicator.start {
            DispatchQueue.global(qos: .utility).async {
                sleep(3)
                DispatchQueue.main.async { [weak self] in
                    self?.activityIndicator.stop()
                }
            }
        }
    }
    
    

}
